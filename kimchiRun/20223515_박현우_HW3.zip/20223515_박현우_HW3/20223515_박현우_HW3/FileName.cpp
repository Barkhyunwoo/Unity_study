﻿#include <stdlib.h>
#include <GL/glut.h>
#include <stdio.h>

// 각 관절의 회전각
static int shoulder = 0, elbow = 0, wrist = 0;
// 선택된 관절
static int selected_joint = 1;

// 인사하는 애니메이션 실행 여부
bool isHi = false;
// 손 흔들기 방향 1 위로, -1 아래로
int isHiWay = 1;


void init(void) {
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_FLAT);
}

void display(void) {
	glClear(GL_COLOR_BUFFER_BIT);
	glPushMatrix();

	// 몸통
	glPushMatrix();
	glTranslatef(-3.0, -1.0, 0.0);
	glScalef(2.0, 3.0, 1.0);
	glutWireCube(1.0);
	glPopMatrix();
	
	// 어깨부터 엘보우까지 (상완)
	glTranslatef(-2.0, 0.0, 0.0);
	glRotatef((GLfloat)shoulder, 0.0, 0.0, 1.0);
	glTranslated(1.0, 0.0, 0.0);
	glPushMatrix();
	glScalef(2.0, 0.4, 1.0);
	glutWireCube(1.0);
	glPopMatrix();

	// 엘보우부터 손목까지 (하완)
	glTranslatef(1.0, 0.0, 0.0);
	glRotatef((GLfloat)elbow, 0.0, 0.0, 1.0);
	glTranslated(1.0, 0.0, 0.0);
	glPushMatrix();
	glScalef(2.0, 0.4, 1.0);
	glutWireCube(1.0);
	glPopMatrix();

	// 손목부터 손까지 (손)
	glTranslatef(1.0, 0.0, 0.0);
	glRotatef((GLfloat)wrist, 0.0, 0.0, 1.0);
	glTranslated(0.25, 0.0, 0.0);
	glPushMatrix();
	glScalef(0.5, 0.5, 1.0);
	glutWireCube(1.0);
	glPopMatrix();

	// 손에서 손가락이 시작되는 끝부분으로 이동
	glTranslatef(0.25, 0.0, 0.0);

	// 첫 번째 손가락 (위)
	glPushMatrix();
	glTranslatef(0.25, 0.15, 0.0);
	glScalef(0.5, 0.05, 0.25);
	glutWireCube(1.0);
	glPopMatrix();

	// 두 번째 손가락 (중간)
	glPushMatrix();
	glTranslatef(0.25, 0.0, 0.0);
	glScalef(0.5, 0.05, 0.25);
	glutWireCube(1.0);
	glPopMatrix();

	// 세 번째 손가락 (아래)
	glPushMatrix();
	glTranslatef(0.25, -0.15, 0.0);
	glScalef(0.5, 0.05, 0.25);
	glutWireCube(1.0);
	glPopMatrix();


	glPopMatrix();
	glutSwapBuffers();

}

void reshape(int w, int h) {
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(65.0, (GLfloat)w / (GLfloat)h, 1.0, 20.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(0.0, 0.0, -5.0);
}

// 팝업 메뉴에서 항목을 선택했을 때 호출되는 함수
void main_menu_select(int value) {

	switch (value) {
	case 1:
		glutSetWindowTitle("어깨"); 
		printf("어깨를 선택하셨습니다.\n");
		selected_joint = 1;						// 조작할 관절을 어깨로 설정
		break;
	case 2:
		glutSetWindowTitle("엘보우");
		printf("엘보우를 선택하셨습니다.\n");
		selected_joint = 2;						// 조작할 관절을 엘보우로 설정
		break;
	case 3:
		glutSetWindowTitle("손목");
		printf("손목을 선택하셨습니다.\n");
		selected_joint = 3;						// 조작할 관절을 손목으로 설정
		break;
	}
}

// s키를 눌렀을 때 실행되는 인사 애니메이션 타이머 함수
void hi(int value) {
	if (!isHi) return; // 애니메이션이 꺼져있으면 종료

	// 손목의 각도가 25보다 크면 -1를 저장
	if (wrist > 25) isHiWay = -1;
	// 손목의 각도가 -25보다 작으면 1를 저장
	else if (wrist < -25) isHiWay = 1;

	// 손목의 각도에 isHiWay에 5를 곱한 후 더하기
	wrist += isHiWay * 5;

	glutPostRedisplay(); // 화면 갱신
	glutTimerFunc(16, hi, 0); // 자기 자신을 다시 호출하여 반복
}

// 키보드 입력을 처리하는 콜백 함수
void keyboard(unsigned char key, int x, int y) {
	switch (key) {
	// u키를 누르면 선택한 각 관절의 최대치까지 회전각 증가
	case 'u': 
		if (selected_joint == 1 && shoulder < 90) shoulder = (shoulder + 5) % 360;
		else if (selected_joint == 2 && elbow < 135) elbow = (elbow + 5) % 360;
		else if (selected_joint == 3 && wrist < 25) wrist = (wrist + 5) % 360;
		glutPostRedisplay();
		break;
	
	// d키를 누르면 선택한 각 관절의 최소치까지 회전각 감소
	case 'd':
		if (selected_joint == 1 && shoulder > -90) shoulder = (shoulder - 5) % 360;
		else if (selected_joint == 2 && elbow > 0) elbow = (elbow - 5) % 360;
		else if (selected_joint == 3 && wrist > -25) wrist = (wrist - 5) % 360;
		glutPostRedisplay();
		break;

	// s키를 누르면 인사하는 애니메이션 동작
	case 's' : 
		// 어깨, 엘보우, 손목 관절 회전각 설정
		shoulder = -45;
		elbow = 135;
		wrist = 0;
		
		// 애니메이션 켜기 토글
		isHi = !isHi; 

		// 애니메이션이 켜져있으면
		if (isHi) {
			// hi를 호출하여 애니메이션 시작
			glutTimerFunc(16, hi, 0); 
		}
		break;

	// ESC 키를 누르면 프로그램 종료
	case 27:
		exit(0);
		break;

	default:
		break;
	}
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(800, 800);
	glutInitWindowPosition(100, 100);
	glutCreateWindow(argv[0]);
	init();

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);

	// 메뉴 생성
	glutCreateMenu(main_menu_select);
	glutAddMenuEntry("어깨", 1);		// 어깨 1번
	glutAddMenuEntry("엘보우", 2);		// 엘보우  2번
	glutAddMenuEntry("손목", 3);		// 손목 관절 3번
	glutAttachMenu(GLUT_RIGHT_BUTTON);	// 우클릭에 메뉴 연결

	glutMainLoop();
	return 0;
}